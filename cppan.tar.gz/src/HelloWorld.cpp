#include "HelloWorld.h"

using namespace BareLibrary;

std::string HelloWorld::sayHello()
{
  return "Hello World!";
}
